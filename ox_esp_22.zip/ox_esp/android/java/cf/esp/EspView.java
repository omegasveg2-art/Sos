package cf.esp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

final class EspView extends View {
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();
    private final float[] cam = new float[6], a = new float[2], b = new float[2], tmp = new float[2];
    private boolean running;
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            invalidate();
            postOnAnimation(this);          // redraw on every vsync so the prediction runs at display rate
        }
    };

    EspView(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        fill.setStyle(Paint.Style.FILL);
        text.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
    }

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); running = true; postOnAnimation(tick); }
    @Override protected void onDetachedFromWindow() { running = false; super.onDetachedFromWindow(); }

    private static int alpha(int c, int al) { return Color.argb(al, Color.red(c), Color.green(c), Color.blue(c)); }

    private void label(Canvas c, String t, float cx, float baseY, float k, int col) {
        text.setTextSize(10.5f * k);
        text.setTextAlign(Paint.Align.CENTER);
        float w = text.measureText(t), h = 12f * k;
        rf.set(cx - w / 2 - 4 * k, baseY - h + 2 * k, cx + w / 2 + 4 * k, baseY + 3 * k);
        fill.setShader(null);
        fill.setColor(Color.argb(130, 8, 10, 12));
        c.drawRoundRect(rf, 3 * k, 3 * k, fill);
        text.setColor(col);
        c.drawText(t, cx, baseY, text);
    }

    @Override
    protected void onDraw(Canvas c) {
        final float W = getWidth(), H = getHeight();
        final float k = Math.max(1f, H / 540f);
        Snap s = Model.snap;
        // Silent FOV circle: converts the degree radius the core uses into screen px for THIS view's own vertical fov, so it
        // tracks what the core actually accepts as a target even if the camera FOV slider changes. Does not depend on game data.
        if (Cfg.b("showFov") && Cfg.b("sil")) {
            float camFov = Math.max(1f, Cfg.f("camFov"));
            float r = (H / 2f) * (float) (Math.tan(Math.toRadians(Cfg.f("sfov"))) / Math.tan(Math.toRadians(camFov / 2f)));
            stroke.setShader(null); stroke.setStrokeWidth(1.4f * k);
            stroke.setColor(Color.argb(150, 255, 90, 90));
            c.drawCircle(W / 2, H / 2, Math.max(4f * k, r), stroke);
        }
        if (!s.ok) {
            text.setTextSize(11f * k); text.setTextAlign(Paint.Align.LEFT); text.setColor(Color.WHITE);
            c.drawText("Astral: " + s.status, 12f * k, H - 12f * k, text);
            return;
        }
        final int enemy = Cfg.enemyColor(), team = Cfg.teamColor();
        final boolean chams = Cfg.b("chams"), glow = Cfg.b("glow"), corner = Cfg.i("boxStyle") == 1;

        // --- time compensation: extrapolate the camera (and players) from the last real update to "now + display latency"
        final long tq = System.nanoTime() + (long) (Cfg.f("lat") * 1e6f);        // negative lat = show an older camera (overlay ahead of the game picture)
        Model.camAt(s, tq, cam);
        final float dt = Math.max(-0.25f, Math.min(0.25f, (tq - s.tData) / 1e9f));
        final float fov = Model.effFov(s.fov, Cfg.f("fovScale"), Cfg.b("fovH"), W / H);

        if (Cfg.b("crosshair")) { fill.setShader(null); fill.setColor(Color.argb(220, 255, 255, 255)); c.drawCircle(W / 2, H / 2, 2.2f * k, fill); }

        if (Cfg.b("esp")) {
            final float maxDist = Cfg.f("maxDist"), boxH = Cfg.f("boxH"), crouchH = Cfg.f("crouchH");
            final float fl = (float) Math.sqrt(cam[3] * cam[3] + cam[5] * cam[5]);
            for (Player p : s.players) {
                if (p.local() || p.dead()) continue;
                boolean mate = p.mate() || (s.localTeam >= 1 && s.localTeam <= 2 && p.team == s.localTeam);
                if (mate && Cfg.b("teamCheck")) continue;
                float px = p.x + p.vx * dt, py = p.y, pz = p.z + p.vz * dt;
                float dx = px - cam[0], dy = py - cam[1], dz = pz - cam[2];
                float dist = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (dist > maxDist) continue;
                int col = mate ? team : enemy;
                float h = p.crouch() ? crouchH : boxH;
                boolean vis = Model.w2s(cam, fov, px, py, pz, W, H, a) && Model.w2s(cam, fov, px, py + h, pz, W, H, b);
                float bh = vis ? a[1] - b[1] : 0f;
                float cx = (a[0] + b[0]) * 0.5f;
                if (!vis || bh < 2f || cx < -W * 0.3f || cx > W * 1.3f) {
                    if (Cfg.b("offscreen") && fl > 1e-4f) drawArrow(c, W, H, k, col, dx, dz, cam[3] / fl, cam[5] / fl);
                    continue;
                }
                float bw = bh * 0.42f;
                float l = cx - bw / 2, r = cx + bw / 2, t = b[1], bt = a[1];

                if (chams) drawBody(c, cx, t, bt, bw, bh, col, k);
                if (Cfg.b("skeleton")) drawSkeleton(c, cx, t, bt, bw, bh, k);
                stroke.setShader(null);
                if (glow) {
                    for (int i = 3; i >= 1; i--) {
                        stroke.setStrokeWidth((1.5f + i * 2.2f) * k);
                        stroke.setColor(alpha(col, 26));
                        if (corner) cornerBox(c, l, t, r, bt, bw, bh); else c.drawRoundRect(l, t, r, bt, 3 * k, 3 * k, stroke);
                    }
                }
                stroke.setStrokeWidth(3.6f * k);
                stroke.setColor(Color.argb(150, 0, 0, 0));
                if (corner) cornerBox(c, l, t, r, bt, bw, bh); else c.drawRoundRect(l, t, r, bt, 3 * k, 3 * k, stroke);
                stroke.setStrokeWidth(1.7f * k);
                stroke.setColor(col);
                if (corner) cornerBox(c, l, t, r, bt, bw, bh); else c.drawRoundRect(l, t, r, bt, 3 * k, 3 * k, stroke);
                boolean locked = p.actor == s.lock && s.lock != 0;
                if (locked) {                                   // aimbot target: bright tag + line from the crosshair
                    stroke.setStrokeWidth(1.2f * k); stroke.setColor(Color.argb(200, 255, 255, 255));
                    c.drawLine(W / 2, H / 2, cx, t + bh * 0.08f, stroke);
                    label(c, "LOCK", cx, bt + 28f * k, k, Color.rgb(255, 214, 64));
                }

                if (Cfg.b("headDot") && Model.w2s(cam, fov, px, py + (p.crouch() ? 1.2f : 1.62f), pz, W, H, tmp)) {
                    fill.setColor(Color.WHITE); c.drawCircle(tmp[0], tmp[1], Math.max(2f * k, bh * 0.028f), fill);
                    stroke.setStrokeWidth(1f * k); stroke.setColor(col); c.drawCircle(tmp[0], tmp[1], Math.max(2f * k, bh * 0.028f) + 1.5f * k, stroke);
                }
                if (Cfg.b("health")) {
                    float f = Math.max(0f, Math.min(1f, p.hp / 100f)), x = l - 7f * k, bwid = 3.4f * k;
                    fill.setShader(null); fill.setColor(Color.argb(190, 0, 0, 0));
                    rf.set(x - 1.2f * k, t - 1.2f * k, x + bwid + 1.2f * k, bt + 1.2f * k); c.drawRoundRect(rf, 2.5f * k, 2.5f * k, fill);
                    int top = Color.rgb((int) (255 * (1 - f)), (int) (90 + 165 * f), 70), bot = Color.rgb((int) (255 * (1 - f) * 0.7f), (int) ((90 + 165 * f) * 0.7f), 50);
                    fill.setShader(new LinearGradient(0, bt - bh * f, 0, bt, top, bot, Shader.TileMode.CLAMP));
                    rf.set(x, bt - bh * f, x + bwid, bt); c.drawRoundRect(rf, 2f * k, 2f * k, fill);
                    fill.setShader(null);
                    stroke.setShader(null); stroke.setStrokeWidth(0.8f * k); stroke.setColor(Color.argb(160, 0, 0, 0));
                    for (int q = 1; q < 4; q++) { float yy = bt - bh * q / 4f; c.drawLine(x, yy, x + bwid, yy, stroke); }
                    if (Cfg.b("hpText")) {
                        text.setTextSize(9f * k); text.setTextAlign(Paint.Align.RIGHT); text.setColor(Color.WHITE);
                        text.setShadowLayer(2f * k, 0, 0, Color.BLACK);
                        c.drawText(String.valueOf(p.hp), x - 3f * k, Math.max(t + 8f * k, bt - bh * f + 4f * k), text);
                        text.clearShadowLayer();
                    }
                }
                if (Cfg.b("name") && !p.name.isEmpty()) label(c, p.name, cx, t - 6f * k, k, locked ? Color.rgb(255, 214, 64) : Color.WHITE);
                if (Cfg.b("dist")) label(c, (int) dist + "m", cx, bt + 14f * k, k, Color.rgb(205, 210, 218));
                if (Cfg.b("bombEsp") && s.bombState == 1 && p.actor == s.bombOwner) label(c, "BOMB", cx, bt + 28f * k + (locked ? 14f * k : 0f), k, Color.rgb(255, 150, 40));
                if (Cfg.b("snap")) { stroke.setStrokeWidth(1f * k); stroke.setColor(alpha(col, 190)); c.drawLine(W / 2, H, cx, bt, stroke); }
            }
        }
        if (Cfg.b("bombEsp")) drawBomb(c, s, W, H, k, fov);
        if (Cfg.b("hud") && Cfg.b("esp")) drawHud(c, s, W, k);
        if (!s.info.isEmpty()) {
            text.setTextSize(9f * k); text.setTextAlign(Paint.Align.LEFT); text.setColor(Color.argb(150, 255, 255, 255));
            c.drawText(s.info, 12f * k, H - 10f * k, text);
        }
        if (Cfg.b("radar") && Cfg.b("esp")) drawRadar(c, s, W, k, fov, W / H, enemy, team);
    }

    /** stylised humanoid fill (head, torso, arms, legs): an overlay cannot recolour the real model, this is the closest look */
    private void drawBody(Canvas c, float cx, float t, float bt, float bw, float bh, int col, float k) {
        fill.setShader(new LinearGradient(0, t, 0, bt, alpha(col, 125), alpha(col, 30), Shader.TileMode.CLAMP));
        float hr = bh * 0.072f;
        c.drawCircle(cx, t + bh * 0.085f, hr, fill);
        rf.set(cx - bw * 0.31f, t + bh * 0.165f, cx + bw * 0.31f, t + bh * 0.53f); c.drawRoundRect(rf, bw * 0.13f, bw * 0.13f, fill);
        rf.set(cx - bw * 0.50f, t + bh * 0.175f, cx - bw * 0.34f, t + bh * 0.50f); c.drawRoundRect(rf, bw * 0.08f, bw * 0.08f, fill);
        rf.set(cx + bw * 0.34f, t + bh * 0.175f, cx + bw * 0.50f, t + bh * 0.50f); c.drawRoundRect(rf, bw * 0.08f, bw * 0.08f, fill);
        rf.set(cx - bw * 0.29f, t + bh * 0.54f, cx - bw * 0.02f, bt); c.drawRoundRect(rf, bw * 0.09f, bw * 0.09f, fill);
        rf.set(cx + bw * 0.02f, t + bh * 0.54f, cx + bw * 0.29f, bt); c.drawRoundRect(rf, bw * 0.09f, bw * 0.09f, fill);
        fill.setShader(null);
        stroke.setShader(null); stroke.setStrokeWidth(0.9f * k); stroke.setColor(alpha(col, 110));
        c.drawCircle(cx, t + bh * 0.085f, hr, stroke);
        rf.set(cx - bw * 0.31f, t + bh * 0.165f, cx + bw * 0.31f, t + bh * 0.53f); c.drawRoundRect(rf, bw * 0.13f, bw * 0.13f, stroke);
    }

    /** proportional stick-figure over the box (head/spine/shoulders/arms/pelvis/legs) -- not real bone tracking,
     * the game doesn't expose a skeleton over this protocol; this is a fixed rig fitted to the box, same honest
     * caveat as drawBody's chams fill. Matches the reference look: thin white lines + joint dots. */
    private void drawSkeleton(Canvas c, float cx, float t, float bt, float bw, float bh, float k) {
        stroke.setShader(null); stroke.setStrokeWidth(1.4f * k); stroke.setColor(Color.argb(230, 255, 255, 255));
        fill.setShader(null); fill.setColor(Color.argb(230, 255, 255, 255));
        float headY = t + bh * 0.085f, neckY = t + bh * 0.165f, shY = t + bh * 0.21f, hipY = t + bh * 0.53f,
                kneeY = t + bh * 0.76f, elbowY = t + bh * 0.40f, handY = t + bh * 0.52f;
        float shX = bw * 0.30f, hipX = bw * 0.17f, kneeXOff = bw * 0.10f;
        c.drawLine(cx, headY, cx, hipY, stroke);                                   // spine
        c.drawLine(cx - shX, shY, cx + shX, shY, stroke);                          // shoulders
        c.drawLine(cx - shX, shY, cx - shX * 1.2f, elbowY, stroke);                // left arm
        c.drawLine(cx - shX * 1.2f, elbowY, cx - shX * 0.9f, handY, stroke);
        c.drawLine(cx + shX, shY, cx + shX * 1.2f, elbowY, stroke);                // right arm
        c.drawLine(cx + shX * 1.2f, elbowY, cx + shX * 0.9f, handY, stroke);
        c.drawLine(cx - hipX, hipY, cx + hipX, hipY, stroke);                       // pelvis
        c.drawLine(cx - hipX, hipY, cx - hipX - kneeXOff, kneeY, stroke);           // left leg
        c.drawLine(cx - hipX - kneeXOff, kneeY, cx - hipX, bt, stroke);
        c.drawLine(cx + hipX, hipY, cx + hipX + kneeXOff, kneeY, stroke);           // right leg
        c.drawLine(cx + hipX + kneeXOff, kneeY, cx + hipX, bt, stroke);
        float jr = Math.max(1.3f * k, bh * 0.012f);
        for (float[] j : new float[][]{{cx, neckY}, {cx - shX, shY}, {cx + shX, shY}, {cx - hipX, hipY}, {cx + hipX, hipY},
                {cx - shX * 1.2f, elbowY}, {cx + shX * 1.2f, elbowY}, {cx - hipX - kneeXOff, kneeY}, {cx + hipX + kneeXOff, kneeY}})
            c.drawCircle(j[0], j[1], jr, fill);
    }

    /** planted bomb: world marker with the countdown (position from the game when readable) and a top pill that always shows the timer */
    private void drawBomb(Canvas c, Snap s, float W, float H, float k, float fov) {
        if (s.bombState != 2) return;
        final int orange = Color.rgb(255, 150, 40);
        String t = s.bombRem >= 0f ? String.format(java.util.Locale.US, "%.1fs", s.bombRem) : "planted";
        int urgent = s.bombRem >= 0f && s.bombRem < 10f ? Color.rgb(255, 70, 60) : orange;
        text.setTextSize(11f * k); text.setTextAlign(Paint.Align.CENTER);
        String pill = "BOMB  " + t;
        float w = text.measureText(pill) + 22f * k, y = 56f * k;
        rf.set(W / 2 - w / 2, y - 14f * k, W / 2 + w / 2, y + 8f * k);
        fill.setShader(null); fill.setColor(Color.argb(160, 8, 10, 12)); c.drawRoundRect(rf, 11f * k, 11f * k, fill);
        stroke.setShader(null); stroke.setStrokeWidth(1.2f * k); stroke.setColor(urgent); c.drawRoundRect(rf, 11f * k, 11f * k, stroke);
        text.setColor(Color.WHITE); c.drawText(pill, W / 2, y, text);
        if (!s.bombHas || !Model.w2s(cam, fov, s.bx, s.by + 0.2f, s.bz, W, H, tmp)) return;
        float dx = s.bx - cam[0], dy = s.by - cam[1], dz = s.bz - cam[2];
        float d = (float) Math.sqrt(dx * dx + dy * dy + dz * dz), r = 9f * k;
        path.reset();
        path.moveTo(tmp[0], tmp[1] - r); path.lineTo(tmp[0] + r, tmp[1]); path.lineTo(tmp[0], tmp[1] + r); path.lineTo(tmp[0] - r, tmp[1]); path.close();
        fill.setColor(alpha(urgent, 90)); c.drawPath(path, fill);
        stroke.setStrokeWidth(1.8f * k); stroke.setColor(urgent); c.drawPath(path, stroke);
        label(c, "BOMB " + t + "  " + (int) d + "m", tmp[0], tmp[1] - r - 6f * k, k, urgent);
    }

    /** top-centre pill: how many enemies are alive and how far the nearest one is */
    private void drawHud(Canvas c, Snap s, float W, float k) {
        int n = 0; float best = 1e9f;
        for (Player p : s.players) {
            if (p.local() || p.dead()) continue;
            if (p.mate() || (s.localTeam >= 1 && s.localTeam <= 2 && p.team == s.localTeam)) continue;
            n++;
            float dx = p.x - cam[0], dy = p.y - cam[1], dz = p.z - cam[2];
            best = Math.min(best, (float) Math.sqrt(dx * dx + dy * dy + dz * dz));
        }
        String t = n == 0 ? "no enemies" : n + (n == 1 ? " enemy" : " enemies") + "  \u00b7  " + (int) best + "m";
        text.setTextSize(11f * k); text.setTextAlign(Paint.Align.CENTER);
        float w = text.measureText(t) + 22f * k, y = 28f * k;
        rf.set(W / 2 - w / 2, y - 14f * k, W / 2 + w / 2, y + 8f * k);
        fill.setShader(null); fill.setColor(Color.argb(150, 8, 10, 12)); c.drawRoundRect(rf, 11f * k, 11f * k, fill);
        stroke.setShader(null); stroke.setStrokeWidth(1f * k); stroke.setColor(n == 0 ? Color.argb(120, 160, 170, 180) : Color.argb(190, 255, 90, 70));
        c.drawRoundRect(rf, 11f * k, 11f * k, stroke);
        text.setColor(Color.WHITE); c.drawText(t, W / 2, y, text);
    }

    private void cornerBox(Canvas c, float l, float t, float r, float bt, float bw, float bh) {
        float lx = bw * 0.30f, ly = bh * 0.16f;
        c.drawLine(l, t, l + lx, t, stroke); c.drawLine(l, t, l, t + ly, stroke);
        c.drawLine(r, t, r - lx, t, stroke); c.drawLine(r, t, r, t + ly, stroke);
        c.drawLine(l, bt, l + lx, bt, stroke); c.drawLine(l, bt, l, bt - ly, stroke);
        c.drawLine(r, bt, r - lx, bt, stroke); c.drawLine(r, bt, r, bt - ly, stroke);
    }

    /** arrow on a ring around the crosshair pointing at an enemy that is behind / outside the screen */
    private void drawArrow(Canvas c, float W, float H, float k, int col, float dx, float dz, float fx, float fz) {
        float rx = fz, rz = -fx;
        float ang = (float) Math.atan2(dx * rx + dz * rz, dx * fx + dz * fz);          // 0 = ahead, +pi/2 = right
        float R = Math.min(W, H) * 0.40f, sx = W / 2 + (float) Math.sin(ang) * R, sy = H / 2 - (float) Math.cos(ang) * R;
        float ux = (float) Math.sin(ang), uy = -(float) Math.cos(ang), s = 11f * k;
        path.reset();
        path.moveTo(sx + ux * s, sy + uy * s);
        path.lineTo(sx - ux * s * 0.6f - uy * s * 0.8f, sy - uy * s * 0.6f + ux * s * 0.8f);
        path.lineTo(sx - ux * s * 0.6f + uy * s * 0.8f, sy - uy * s * 0.6f - ux * s * 0.8f);
        path.close();
        fill.setShader(null); fill.setColor(alpha(col, 215));
        c.drawPath(path, fill);
    }

    private void drawRadar(Canvas c, Snap s, float W, float k, float fovV, float aspect, int enemy, int team) {
        float R = 84f * k, ox = W - R - 18f * k, oy = R + 18f * k;
        fill.setShader(null); fill.setColor(Color.argb(120, 8, 10, 12)); c.drawCircle(ox, oy, R, fill);
        stroke.setShader(null); stroke.setStrokeWidth(1f * k);
        stroke.setColor(Color.argb(70, 255, 255, 255));
        c.drawCircle(ox, oy, R, stroke); c.drawCircle(ox, oy, R * 0.5f, stroke);
        c.drawLine(ox - R, oy, ox + R, oy, stroke); c.drawLine(ox, oy - R, ox, oy + R, stroke);
        float hf = (float) Math.atan(Math.tan(Math.toRadians(fovV) * 0.5) * aspect);      // half horizontal fov
        stroke.setColor(Color.argb(110, 90, 176, 255));
        c.drawLine(ox, oy, ox + (float) Math.sin(hf) * R, oy - (float) Math.cos(hf) * R, stroke);
        c.drawLine(ox, oy, ox - (float) Math.sin(hf) * R, oy - (float) Math.cos(hf) * R, stroke);
        float fl = (float) Math.sqrt(cam[3] * cam[3] + cam[5] * cam[5]);
        if (fl < 1e-4f) return;
        float fx = cam[3] / fl, fz = cam[5] / fl, rx = fz, rz = -fx, range = Cfg.f("radarRange");
        for (Player p : s.players) {
            if (p.dead()) continue;
            float x = 0, y = 0;
            if (!p.local()) {
                float dx = p.x - cam[0], dz = p.z - cam[2];
                x = (dx * rx + dz * rz) / range * R; y = -(dx * fx + dz * fz) / range * R;
                float d = (float) Math.sqrt(x * x + y * y);
                if (d > R - 4f * k) { x *= (R - 4f * k) / d; y *= (R - 4f * k) / d; }
            }
            boolean mate = p.mate() || (s.localTeam >= 1 && p.team == s.localTeam);
            fill.setColor(p.local() ? Color.WHITE : (mate ? team : enemy));
            c.drawCircle(ox + x, oy + y, (p.local() ? 3.2f : 2.8f) * k, fill);
        }
    }
}
